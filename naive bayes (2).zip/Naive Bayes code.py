# -*- coding: utf-8 -*-
"""
Created on Sat Jun 24 15:58:34 2023

@author: samya
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.naive_bayes import MultinomialNB
import sklearn.metrics as skmet
import joblib
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler
from sklearn.decomposition import PCA
from sklearn.compose import ColumnTransformer
from feature_engine.outliers import Winsorizer
import joblib, pickle
from sqlalchemy import create_engine
from urllib.parse import quote

# Loading the Train and Test Datasets
Traindata = pd.read_csv(r"SalaryData_Train.csv")
Testdata = pd.read_csv(r"SalaryData_Test.csv")

user_name = 'root'
database = 'amerdb'
your_password = 'dba@123#'
engine = create_engine(f'mysql+pymysql://{user_name}:%s@localhost:3306/{database}' % quote(f'{your_password}'))

Traindata.to_sql('SalaryData_Train', con = engine, if_exists = 'replace', index = False)
Testdata.to_sql('SalaryData_Test', con = engine, if_exists = 'replace', index = False)

#data.to_sql('glass', con = engine, if_exists = 'replace', index = False)

# SELECTING THE ENTIRE DATA FROM DATABASE
sql = "select * from SalaryData_Train"
Traindata = pd.read_sql_query(sql, engine)
Traindata.info()

sql = "select * from SalaryData_Test"
Testdata = pd.read_sql_query(sql, engine)
Testdata.info()


############# Auto EDA ##############
import dtale
d = dtale.show(Traindata)
d.open_browser()
####### 
d = dtale.show(Testdata)
d.open_browser()
# Define the target variable
#target = 'Salary'

# # Splitting data into X (features) and y (target)

Y_test = Testdata[['Salary']]
X_test = Testdata.drop(['Salary'], axis = 1)


Y_train = Traindata[['Salary']]
X_train = Traindata.drop(['Salary'], axis = 1)

from sklearn.preprocessing import LabelEncoder

# Creating instance of labelencoder
labelencoder = LabelEncoder()

# Data Split into Input and Output variables
s_l = labelencoder.fit(Y_train['Salary'])
joblib.dump(s_l, 'label_salary')
Y_train['Salary'] = s_l.transform(Y_train['Salary'])
Y_test['Salary'] = s_l.transform(Y_test['Salary'])
Y_train_1d = Y_train.values.ravel()

# Separating Numeric and Non-Numeric columns
numeric_features = X_train.select_dtypes(include=np.number).columns
categorical_features = X_train.select_dtypes(include='object').columns

# Preprocessing pipeline
num_pipeline = Pipeline(steps=[('impute', SimpleImputer(strategy='mean')), ('scale', MinMaxScaler())])
cat_pipeline = Pipeline(steps=[('encoding', OneHotEncoder(sparse_output=False))])

preprocessor = ColumnTransformer(transformers=[('num', num_pipeline, numeric_features), ('cat', cat_pipeline, categorical_features)])

X_train_processed = preprocessor.fit(X_train)
#file_path = r"data.joblib"
joblib.dump(X_train_processed,'Data26')

# Apply preprocessing on training data

# Apply preprocessing on test data
Xtr = pd.DataFrame(X_train_processed.transform(X_train), columns = X_train_processed.get_feature_names_out())

Xtr.iloc[:,0:5].plot(kind = 'box', subplots = True, sharey = False, figsize = (10, 6)) 

'''sharey True or 'all': x- or y-axis will be shared among all subplots.
False or 'none': each subplot x- or y-axis will be independent.'''

# increase spacing between subplots
plt.subplots_adjust(wspace = 0.75) # ws is the width of the padding between subplots, as a fraction of the average Axes width.
plt.show()
###### Input columns ['num__capitalgain', 'num__capitalloss'] have low variation for method 'iqr'. 
Xtr.columns
columns = ['num__age', 'num__educationno', 'num__hoursperweek']


winsor = Winsorizer(capping_method = 'iqr', # choose  IQR rule boundaries or gaussian for mean and std
                          tail = 'both', # cap left, right or both tails 
                          fold = 1.5,
                          variables = columns)
outlier = winsor.fit(Xtr[columns])
# Save the winsorizer model 
joblib.dump(outlier, 'winsor')
Xtr[columns] = outlier.transform(Xtr[columns])
Xtr.iloc[:,0:5].plot(kind = 'box', subplots = True, sharey = False, figsize = (10, 6)) 
# increase spacing between subplots
plt.subplots_adjust(wspace = 0.75) # ws is the width of the padding between subplots, as a fraction of the average Axes width.
plt.show()

########## transform on test data
Xts = pd.DataFrame(X_train_processed.transform(X_test), columns = X_train_processed.get_feature_names_out())
Xts[columns] = outlier.transform(Xts[columns])

# Creating and fitting the Naive Bayes model
model = MultinomialNB()
nb_model = model.fit(Xtr, Y_train)


### For Train Dataset ###
# Making predictions on the test data
predictions = pd.DataFrame(nb_model.predict(Xtr))

# Evaluating the model
accuracy = skmet.accuracy_score(Y_train, predictions)
print('Accuracy:', accuracy)

# Classification report
classification_report = skmet.classification_report(Y_train, predictions)
print(classification_report)

# Confusion matrix
confusion_matrix = skmet.confusion_matrix(Y_train, predictions)
print(confusion_matrix)

predictions = pd.DataFrame(nb_model.predict(Xtr))

### For Test Dataset ###
predictions_test = pd.DataFrame(nb_model.predict(Xts))

# Evaluating the model
accuracy = skmet.accuracy_score(Y_test, predictions_test)
print('Accuracy:', accuracy)

# Classification report
classification_report = skmet.classification_report(Y_train_1d, predictions)
print(classification_report)

# Confusion matrix
confusion_matrix = skmet.confusion_matrix(Y_train_1d, predictions)
print(confusion_matrix)

predictions = pd.DataFrame(nb_model.predict(Xtr))

##### Hyperparameter Tunning ########
####### GridSearchCV ############
from sklearn.model_selection import GridSearchCV
from sklearn.naive_bayes import MultinomialNB



# Define the parameter grid
param_grid = {
    'alpha': [0.1, 0.5, 1.0, 2.0, 5.0, 0.05, 50.0, 100.0, 500.0, 1000.0]
}

# Create the GaussianNB model
model = MultinomialNB()

# Create the GridSearchCV object
grid_search = GridSearchCV(model, param_grid, scoring='accuracy', cv=5, error_score='raise')

# Fit the GridSearchCV object to the training data
grid_search.fit(Xtr, Y_train)

# Get the best parameters and best score
best_params = grid_search.best_params_
best_score = grid_search.best_score_
best_estimat = grid_search.best_estimator_
print("Best Parameters:", best_params)
print("Best Score:", best_score)

#joblib.dump(best_params,'Data26')

predictions = pd.DataFrame(best_estimat.predict(Xtr))
import sklearn.metrics as skmet

# Evaluating the model
accuracy = skmet.accuracy_score(Y_train, predictions)
print('Accuracy:', accuracy)

# Classification report
classification_report = skmet.classification_report(Y_train, predictions)
print(classification_report)

# Confusion matrix
confusion_matrix = skmet.confusion_matrix(Y_train, predictions)
print(confusion_matrix)

predictions = pd.DataFrame(best_estimat.predict(Xtr))

### For Test Dataset ###
predictions_test = pd.DataFrame(best_estimat.predict(Xts))
import sklearn.metrics as skmet

# Evaluating the model
accuracy = skmet.accuracy_score(Y_test, predictions_test)
print('Accuracy:', accuracy)

# Classification report
classification_report = skmet.classification_report(Y_train_1d, predictions)
print(classification_report)

# Confusion matrix
confusion_matrix = skmet.confusion_matrix(Y_train_1d, predictions)
print(confusion_matrix)

predictions = pd.DataFrame(nb_model.predict(Xtr))

predictions = s_l.inverse_transform(predictions)

joblib.dump(nb_model,'Data27')












